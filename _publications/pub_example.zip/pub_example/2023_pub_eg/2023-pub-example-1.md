---
title:          "Lorem ipsum: Dolor sit amet, consectetur adipiscing elit"
date:           2023-01-05 00:01:00 +0800
selected:       true
pub:            "Nature Communications"
pub_date:       "2023"
abstract: >-
  Photo by Thomas Renaud on Unsplash. Lorem ipsum dolor sit amet, consectetur adipiscing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua. Ut enim ad minim veniam, quis nostrud exercitation ullamco laboris nisi ut aliquip ex ea commodo consequat.
cover:          /assets/images/covers/cover1.jpg
authors:
- Your Name*
- Robert White*
- John Doe
- Charles Green (Stanford)
links:
  Paper: https://www.cell.com
---